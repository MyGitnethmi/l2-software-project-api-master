-- Modify results related to any module and any student.
CREATE PROCEDURE editResults @examID INT, @dateHeld DATE, @results MARKS READONLY AS

    BEGIN TRANSACTION

UPDATE Exam SET dateHeld = @dateHeld WHERE examID = @examID
    IF @@ROWCOUNT = 0 GOTO errorHandler

DECLARE cursor_results CURSOR FOR SELECT * FROM @results
DECLARE @studentID CHAR(7), @mark INT, @grade VARCHAR(2)

    OPEN cursor_results
    FETCH NEXT FROM cursor_results INTO @studentID, @mark
    WHILE @@FETCH_STATUS = 0
        BEGIN
            EXEC @grade = getGrade @mark
            UPDATE Mark SET mark = @mark, grade = @grade WHERE examID = @examID AND studentID = @studentID
            IF @@ROWCOUNT = 0 GOTO errorHandler
            FETCH NEXT FROM cursor_results INTO @studentID, @mark
        END

    COMMIT TRANSACTION
    RETURN 0
    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction failed'
    RETURN -1
go

