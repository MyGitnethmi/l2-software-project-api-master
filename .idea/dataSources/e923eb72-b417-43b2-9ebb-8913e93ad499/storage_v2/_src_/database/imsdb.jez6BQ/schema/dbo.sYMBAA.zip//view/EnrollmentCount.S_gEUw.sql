CREATE VIEW EnrollmentCount AS
SELECT M.moduleCode, E.batch, COUNT(EM.enrollmentID) count
FROM Module M,
     Enrollment E,
     EnrollmentModule EM
WHERE M.moduleCode = EM.moduleCode
  AND EM.enrollmentID = E.enrollmentID
GROUP BY M.moduleCode, E.batch
go

