CREATE PROCEDURE addNotification @sentBy CHAR(7), @subject VARCHAR(100), @message VARCHAR(500), @timeSent DATETIME,
                                 @recipients RECIPIENTS READONLY AS
    BEGIN TRANSACTION

INSERT INTO Notification (sentby, subject, message, timeSent)
VALUES (@sentBy, @subject, @message, @timeSent);
    IF @@ROWCOUNT = 0 GOTO errorHandler;

DECLARE @recipient VARCHAR(7);
DECLARE
    cursor_recipients CURSOR FOR SELECT *
                                 FROM @recipients

    OPEN cursor_recipients;
    FETCH NEXT FROM cursor_recipients INTO @recipient;
    WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @recipient LIKE REPLICATE('[0-9]', 6) + '[A-Z]'
                BEGIN
                    INSERT INTO Received
                    VALUES (IDENT_CURRENT('Notification'), CAST(@recipient AS CHAR(7)),
                            IIF(@recipient = @sentBy, 1, 0));
                    IF @@ROWCOUNT = 0 GOTO errorHandler;
                END
            ELSE
                IF @recipient LIKE '20' + REPLICATE('[0-9]', 2)
                    BEGIN
                        DECLARE cursor_batch CURSOR FOR SELECT studentID
                                                        FROM Student
                                                        WHERE studentID LIKE SUBSTRING(@recipient, 3, 4) + '%';
                        OPEN cursor_batch
                        FETCH NEXT FROM cursor_batch INTO @recipient
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                INSERT INTO Received VALUES (IDENT_CURRENT('Notification'), @recipient, 0)
                                IF @@ROWCOUNT = 0 GOTO errorHandler;
                                FETCH NEXT FROM cursor_batch INTO @recipient
                            END
                    END
            FETCH NEXT FROM cursor_recipients INTO @recipient
        END
    COMMIT TRANSACTION
    RETURN IDENT_CURRENT('Notification');

    errorHandler:
    ROLLBACK TRANSACTION;
    PRINT 'Transaction failed'
    RETURN 0;
go

