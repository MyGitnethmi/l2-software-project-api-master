CREATE FUNCTION getGrade(@mark INT)
    RETURNS VARCHAR(2)
AS
BEGIN
    IF @mark < 30
        RETURN 'F-'
    ELSE
        IF @mark < 35
            RETURN 'F'
        ELSE
            IF @mark < 38
                RETURN 'F+'
            ELSE
                IF @mark < 40
                    RETURN 'D-'
                ELSE
                    IF @mark < 43
                        RETURN 'D'
                    ELSE
                        IF @mark < 48
                            RETURN 'D+'
                        ELSE
                            IF @mark < 50
                                RETURN 'C-'
                            ELSE
                                IF @mark < 54
                                    RETURN 'C'
                                ELSE
                                    IF @mark < 57
                                        RETURN 'C+'
                                    ELSE
                                        IF @mark < 61
                                            RETURN 'B-'
                                        ELSE
                                            IF @mark < 64
                                                RETURN 'B'
                                            ELSE
                                                IF @mark < 67
                                                    RETURN 'B+'
                                                ELSE
                                                    IF @mark < 71
                                                        RETURN 'A-'
                                                    ELSE
                                                        IF @mark < 75
                                                            RETURN 'A'
                                                        ELSE
                                                            RETURN 'A+'
    RETURN 'NA'
END
go

