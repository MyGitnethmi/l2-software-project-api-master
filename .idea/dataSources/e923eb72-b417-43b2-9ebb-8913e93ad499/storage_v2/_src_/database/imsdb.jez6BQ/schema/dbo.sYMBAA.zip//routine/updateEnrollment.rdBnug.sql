CREATE PROCEDURE updateEnrollment @enrollmentID INT, @modules REGISTRATION_MODULE READONLY AS
    BEGIN TRANSACTION

DECLARE @previousModules REGISTRATION_MODULE, @studentID CHAR(7)
INSERT INTO @previousModules SELECT moduleCode FROM EnrollmentModule WHERE enrollmentID = @enrollmentID
SELECT @studentID = studentID FROM Enrollment WHERE enrollmentID = @enrollmentID

DELETE FROM Mark WHERE studentID = @studentID AND enrollmentID IN (
    SELECT E.enrollmentID FROM Enrollment E, EnrollmentModule EM
    WHERE E.enrollmentID = @enrollmentID AND E.enrollmentID = EM.enrollmentID AND EM.moduleCode NOT IN (SELECT * FROM @modules)
) AND examID IN (
    SELECT examID FROM Exam Ex, EnrollmentModule EM, Enrollment E
    WHERE E.enrollmentID = @enrollmentID AND E.enrollmentID = EM.enrollmentID AND EM.moduleCode NOT IN (SELECT * FROM @modules) AND EM.moduleCode = EX.moduleCode AND E.batch = EX.academicYear
)

DELETE FROM Attendance WHERE studentID = '184061R' and sessionID IN (
    SELECT S.sessionID as sessionID
    FROM Session S, Attendance A, Enrollment E, EnrollmentModule EM, LectureHour L
    WHERE E.enrollmentID = 1 AND
            E.enrollmentID = EM.enrollmentID AND
            EM.moduleCode = L.moduleCode AND
            EM.moduleCode NOT IN (SELECT * FROM @modules) AND
            L.lectureHourID = S.lectureHourID AND
            E.batch = S.batch AND
            S.sessionID = A.sessionID AND
            A.studentID = '184061R'
)

DELETE FROM EnrollmentModule WHERE enrollmentID = @enrollmentID AND moduleCode NOT IN (SELECT * FROM @modules)

INSERT INTO EnrollmentModule SELECT @enrollmentID, moduleCode FROM @modules WHERE moduleCode NOT IN (SELECT * FROM @previousModules)

    COMMIT TRANSACTION
    RETURN 0

    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction failed'
    RETURN -1;
go

