create PROCEDURE uploadPayment @paymentID int,
                               @slipNo CHAR(50),
                               @amount INT,
                               @paymentDate DATE,
                               @bank CHAR(50),
                               @studentID CHAR(7),
                               @externalNote CHAR(100),
                               @paymentStatus INT,
                               @new BIT,
                               @role INT
AS
    BEGIN TRANSACTION

    if @new = 1
        begin
            IF EXISTS(SELECT 1 FROM Student WHERE studentID = @studentID)
                BEGIN
                    INSERT INTO Payment (slipNo, amount, paymentDate, bank, studentID, externalNote, confirmStatus)
                    VALUES (@slipNo, @amount, @paymentDate, @bank, @studentID, @externalNote, @paymentStatus)
                END
            ELSE
                begin
                    goto errorHandler
                end
        end
    else
        begin
            if (@role = 3)
                begin
                    if exists(select 1 from Payment where id = @paymentID and studentID = @studentID and confirmStatus = 1)
                        begin
                            update Payment set slipNo = @slipNo, amount = @amount, paymentDate = @paymentDate, bank = @bank, externalNote = @externalNote
                            where id = @paymentID and studentID = @studentID
                        end
                    else
                        begin
                            goto errorHandler
                        end
                end
            else
                begin
                    if exists(select 1 from Payment where id = @paymentID and studentID = @studentID)
                        begin
                            update Payment set slipNo = @slipNo, amount = @amount, paymentDate = @paymentDate, bank = @bank, externalNote = @externalNote, confirmStatus = @paymentStatus
                            where id = @paymentID and studentID = @studentID
                        end
                    else
                        begin
                            goto errorHandler
                        end
                end
        end

    COMMIT TRANSACTION
    RETURN iif (@new = 1, IDENT_CURRENT('Payment'), @paymentID);

    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction failed..!'
    RETURN -1
go

