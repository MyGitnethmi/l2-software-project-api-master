CREATE PROCEDURE getResults @studentID CHAR(7) AS

SELECT M.moduleCode, M.moduleName, M.credits, E.semester, Ex.academicYear, Ex.dateHeld, Ma.mark, Ma.grade
FROM Enrollment E, EnrollmentModule Em, Module M, Exam Ex, Mark Ma
WHERE E.studentID = @studentID
  AND E.enrollmentID = Em.enrollmentID
  AND Em.moduleCode = Ex.moduleCode
  AND Em.moduleCode = M.moduleCode
  AND Ex.examID = Ma.examID
  AND E.batch = Ex.academicYear
  AND Ma.studentID = @studentID
go

