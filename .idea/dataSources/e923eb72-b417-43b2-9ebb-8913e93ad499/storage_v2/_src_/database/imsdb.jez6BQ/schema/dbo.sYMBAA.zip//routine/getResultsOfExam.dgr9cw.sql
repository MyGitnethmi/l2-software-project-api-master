CREATE PROCEDURE getResultsOfExam @moduleCode CHAR(6), @academicYear INT AS

SELECT examID, dateHeld FROM Exam WHERE moduleCode = @moduleCode AND academicYear = @academicYear
SELECT M.studentID, M.mark, M.grade FROM Exam E, Mark M WHERE E.moduleCode = @moduleCode AND E.academicYear = @academicYear AND E.examID = M.examID
go

