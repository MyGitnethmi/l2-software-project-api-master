CREATE PROCEDURE updateAcademicCalender @academicYears ACADEMIC_YEARS READONLY, @tasks ACADEMIC_YEAR_TASKS READONLY AS

DELETE
FROM AcademicYearTasks
    DBCC CHECKIDENT ('AcademicYearTasks', RESEED, 0)

DELETE
FROM AcademicCalender

DECLARE @year INT
DECLARE
    cursor_academicYears CURSOR FOR SELECT *
                                    FROM @academicYears
    OPEN cursor_academicYears
    FETCH NEXT FROM cursor_academicYears INTO @year
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO AcademicCalender VALUES (@year)
            FETCH NEXT FROM cursor_academicYears INTO @year
        END

DECLARE @taskName VARCHAR(30), @startDate DATE, @endDate DATE
DECLARE
    cursor_tasks CURSOR FOR SELECT *
                            FROM @tasks
    OPEN cursor_tasks
    FETCH NEXT FROM cursor_tasks INTO @year, @taskName, @startDate, @endDate
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO AcademicYearTasks (AcademicYear, TaskName, StartDate, EndDate)
            VALUES (@year, @taskName, @startDate, @endDate)
            FETCH NEXT FROM cursor_tasks INTO @year, @taskName, @startDate, @endDate
        END
go

