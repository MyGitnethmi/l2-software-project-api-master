create PROCEDURE getPendingPaymentsList AS
SELECT P.id, P.amount, S.studentID, U.title, S.fullName, C.courseName, P.paymentDate, P.slipNo
FROM Payment P,
     Student S,
     Users U,
     Course C
WHERE P.confirmStatus = 1
  AND P.studentID = S.studentID
  AND S.StudentID = U.username
  AND S.courseId = C.courseID
ORDER BY P.paymentDate ASC
go

