CREATE PROCEDURE getModuleDetails @moduleCode CHAR(6) AS
    IF EXISTS(SELECT *
              FROM Module
              WHERE moduleCode = @moduleCode)
        BEGIN

            SELECT *
            FROM Module
            WHERE moduleCode = @moduleCode;

            SELECT U.username, U.firstName, U.lastName
            FROM Assignment A,
                 Users U
            WHERE A.moduleCode = @moduleCode
              AND A.teacherID = U.username;

            SELECT L.lectureHourID,
                   L.type,
                   CONVERT(VARCHAR(8), L.startingTime, 8) AS startingTime,
                   CONVERT(VARCHAR(8), L.endingTime, 8)   AS endingTime,
                   L.day,
                   L.lectureHall
            FROM LectureHour L
            WHERE L.moduleCode = @moduleCode;

            RETURN 0;

        END
    ELSE
        RETURN -1;
go

