create PROCEDURE getStudentResults @studentID CHAR(7) AS

SELECT M.moduleCode, M.moduleName, E.semester, Ex.academicYear, Ex.dateHeld, Ma.grade, Ma.mark
FROM Enrollment E, EnrollmentModule EM, Module M, Exam Ex, Mark Ma
WHERE E.studentID = @studentID
  AND E.enrollmentID = EM.enrollmentID
  AND EM.moduleCode = Ex.moduleCode
  AND EM.moduleCode = M.moduleCode
  AND Ex.examID = Ma.examID
  AND E.enrollmentID = Ma.enrollmentID
go

