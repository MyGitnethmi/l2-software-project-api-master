CREATE PROCEDURE changePassword @username CHAR(7), @password VARCHAR(300) AS
BEGIN
    IF EXISTS(SELECT 1 FROM Users WHERE username = @username)
        BEGIN
            UPDATE Users SET password = @password WHERE username = @username
            RETURN 0
        END
    ELSE
        RETURN -1
END
go

