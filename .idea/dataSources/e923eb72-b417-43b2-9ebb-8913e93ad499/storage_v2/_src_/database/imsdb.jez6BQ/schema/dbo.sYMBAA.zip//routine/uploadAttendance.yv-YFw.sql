CREATE PROCEDURE uploadAttendance @lectureHourID INT, @batch INT, @date DATE, @time CHAR(5), @attendance SESSION_ATTENDANCE READONLY AS
    BEGIN TRANSACTION
INSERT INTO Session (lectureHourID, date, batch)
VALUES (@lectureHourID, DATEADD(day, 1, CAST(@date AS DATETIME) + CAST(@time AS DATETIME)), @batch)
    IF @@ROWCOUNT = 0 GOTO errorHandler

DECLARE cursor_attendance CURSOR FOR SELECT * FROM @attendance
DECLARE @record CHAR(7), @status BIT

    OPEN cursor_attendance
    FETCH NEXT FROM cursor_attendance INTO @record, @status
    WHILE @@FETCH_STATUS = 0
        BEGIN
            IF EXISTS(
                    SELECT 1 FROM LectureHour L, Enrollment E, EnrollmentModule EM
                    WHERE L.moduleCode = EM.moduleCode AND EM.enrollmentID = E.enrollmentID AND E.batch = @batch AND E.studentID = @record
                )
                BEGIN
                    IF (@status = 0)
                        BEGIN
                            INSERT INTO Attendance VALUES (IDENT_CURRENT('Session'), @record)
                            IF @@ROWCOUNT = 0 GOTO errorHandler
                        END
                    FETCH NEXT FROM cursor_attendance INTO @record, @status
                END
            ELSE
                BEGIN
                    GOTO errorHandler;
                END
        END
    COMMIT TRANSACTION
    RETURN 0

    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction failed!'
    RETURN 1
go

