CREATE PROCEDURE getModules @username CHAR(7), @role INT AS
    IF @role = 3
        BEGIN

            SELECT M.moduleCode, M.moduleName, M.description, M.credits, E.semester
            FROM Enrollment E,
                 EnrollmentModule EM,
                 Module M
            WHERE E.studentID = @username
              AND E.enrollmentID = EM.enrollmentID
              AND EM.moduleCode = M.moduleCode

            SELECT A.moduleCode, U.firstName, U.lastName
            FROM Users U,
                 Assignment A,
                 Enrollment E,
                 EnrollmentModule EM
            WHERE E.studentID = @username
              AND EM.enrollmentID = E.enrollmentID
              AND A.moduleCode = EM.moduleCode
              AND A.teacherID = U.username
            GROUP BY A.moduleCode, U.firstName, U.lastName

            SELECT L.moduleCode,
                   L.type,
                   CONVERT(VARCHAR(8), L.startingTime, 8) AS startingTime,
                   CONVERT(VARCHAR(8), L.endingTime, 8)   AS endingTime,
                   L.day,
                   L.lectureHall
            FROM Enrollment E,
                 EnrollmentModule EM,
                 LectureHour L
            WHERE E.studentID = @username
              AND E.enrollmentID = EM.enrollmentID
              AND EM.moduleCode = L.moduleCode
            GROUP BY L.moduleCode, L.type, L.startingTime, L.endingTime, L.day, L.lectureHall

            SELECT C.courseID, C.courseName
            FROM Student S,
                 Course C
            WHERE S.studentID = @username
              AND C.courseID = S.courseID

        END
    ELSE
        IF @role = 2
            BEGIN

                SELECT M.moduleCode, M.moduleName, M.description, M.credits
                FROM Assignment A,
                     Module M
                WHERE A.teacherID = @username
                  AND A.moduleCode = M.moduleCode


                SELECT A.moduleCode, U.firstName, U.lastName
                FROM Users U,
                     Assignment A
                WHERE A.moduleCode IN (SELECT A1.moduleCode FROM Assignment A1 WHERE A1.teacherID = @username)
                  AND A.teacherID = U.username

                SELECT L.moduleCode,
                       L.type,
                       CONVERT(VARCHAR(8), L.startingTime, 8) AS startingTime,
                       CONVERT(VARCHAR(8), L.endingTime, 8)   AS endingTime,
                       L.day,
                       L.lectureHall
                FROM Assignment A,
                     LectureHour L
                WHERE A.teacherID = @username
                  AND A.moduleCode = L.moduleCode

            END
        ELSE
            BEGIN

                SELECT * FROM Module

                SELECT A.moduleCode, U.firstName, U.lastName
                FROM Assignment A,
                     Users U
                WHERE A.teacherID = U.username

                SELECT moduleCode,
                       type,
                       CONVERT(VARCHAR(8), startingTime, 8) AS startingTime,
                       CONVERT(VARCHAR(8), endingTime, 8)   AS endingTime,
                       day,
                       lectureHall
                FROM LectureHour

            END
go

