CREATE PROCEDURE getAcademicCalenders AS

SELECT *
FROM AcademicCalender

SELECT *
FROM AcademicYearTasks
go

