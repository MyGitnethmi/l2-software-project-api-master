CREATE PROCEDURE viewPaymentDetails @slipNo INT AS
SELECT P.amount,
       P.slipNo,
       P.paymentDate,
       P.bank,
       S.studentID,
       U.title,
       S.fullName,
       S.academicYear,
       C.courseName
FROM Payment P,
     Student S,
     Users U,
     Course C
WHERE P.slipNo = @slipNo
  AND P.studentID = S.studentID
  AND S.courseID = C.courseID
  AND S.studentID = U.username
ORDER BY P.paymentDate ASC
go

