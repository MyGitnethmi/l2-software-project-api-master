CREATE PROCEDURE getRequestDetails @requestID INT, @username CHAR(7), @role INT AS
    IF @role = 3
        BEGIN
            IF NOT EXISTS(SELECT 1 FROM Request WHERE requestID = @requestID AND submittedBY = @username)
                RETURN 0;
            ELSE
                SELECT * FROM Request WHERE requestID = @requestID AND submittedBY = @username
        END
    ELSE
        IF @role = 1
            BEGIN
                SELECT * FROM Request WHERE requestID = @requestID
            END
        ELSE
            BEGIN
                RETURN -1;
            END
SELECT status, reviewedBy, reason
FROM RequestProgress
WHERE requestID = @requestID
SELECT requestReasonID, reason
FROM RequestReason
WHERE requestID = @requestID
SELECT *
FROM RequestReviewer
SELECT *
FROM RequestsMade
WHERE requestID = @requestID
go

