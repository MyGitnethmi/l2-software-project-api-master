CREATE PROCEDURE addModule @moduleCode CHAR(6),
                           @moduleName VARCHAR(50),
                           @description VARCHAR(500),
                           @credits REAL,
                           @lectureHours LECTURE_HOUR READONLY,
                           @teachers TEACHER READONLY
AS
    BEGIN TRANSACTION

DECLARE
    @lectureHourID INT, @type VARCHAR(15), @day INT, @lectureHall VARCHAR(20), @startingTIme CHAR(8), @endingTime CHAR(8), @teacherID CHAR(7)
    IF EXISTS(SELECT *
              FROM Module
              WHERE moduleCode = @moduleCode)
        BEGIN

            UPDATE Module
            SET moduleName=@moduleName,
                description=@description,
                credits=@credits
            WHERE moduleCode = @moduleCode
            IF @@ROWCOUNT = 0 GOTO errorHandler

            IF EXISTS(SELECT 1 FROM @lectureHours WHERE lectureHourID != 0)
                BEGIN

                    DELETE
                    FROM LectureHour
                    WHERE lectureHourID NOT IN (SELECT lectureHourID FROM @lectureHours)
                      AND moduleCode = @moduleCode

                    DECLARE cursor_lectureHours CURSOR FOR SELECT * FROM @lectureHours WHERE lectureHourID != 0
                    OPEN cursor_lectureHours
                    FETCH NEXT FROM cursor_lectureHours INTO @lectureHourID, @type, @day, @lectureHall, @startingTime, @endingTime
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            UPDATE LectureHour
                            SET type=@type,
                                startingTime=@startingTIme,
                                endingTime=@endingTime,
                                day=@day,
                                lectureHall=@lectureHall
                            WHERE lectureHourID = @lectureHourID
                            IF @@ROWCOUNT = 0 GOTO errorHandler
                            FETCH NEXT FROM cursor_lectureHours INTO @lectureHourID, @type, @day, @lectureHall, @startingTime, @endingTime
                        END

                END

            DELETE FROM Assignment WHERE moduleCode = @moduleCode

        END
    ELSE
        BEGIN

            INSERT INTO Module
            VALUES (@moduleCode, @moduleName, @description, @credits)
            IF @@ROWCOUNT = 0 GOTO errorHandler

        END
    IF EXISTS(SELECT 1
              FROM @lectureHours
              WHERE lectureHourID = 0)
        BEGIN
            DECLARE cursor_newLectureHours CURSOR FOR SELECT * FROM @lectureHours WHERE lectureHourID = 0
            OPEN cursor_newLectureHours
            FETCH NEXT FROM cursor_newLectureHours INTO @lectureHourID, @type, @day, @lectureHall, @startingTime, @endingTime
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    INSERT INTO LectureHour (moduleCode, type, startingTime, endingTime, day, lectureHall)
                    VALUES (@moduleCode, @type, @startingTIme, @endingTime, @day, @lectureHall)
                    IF @@ROWCOUNT = 0 GOTO errorHandler
                    FETCH NEXT FROM cursor_newLectureHours INTO @lectureHourID, @type, @day, @lectureHall, @startingTime, @endingTime
                END
        END

DECLARE
    cursor_teachers CURSOR FOR SELECT *
                               FROM @teachers
    OPEN cursor_teachers
    FETCH NEXT FROM cursor_teachers INTO @teacherID
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO Assignment VALUES (@teacherID, @moduleCode)
            IF @@ROWCOUNT = 0 GOTO errorHandler
            FETCH NEXT FROM cursor_teachers INTO @teacherID
        END

    COMMIT TRANSACTION
    RETURN 0
    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction Failed..!'
    RETURN -1
go

