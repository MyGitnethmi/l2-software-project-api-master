CREATE PROCEDURE getEnrollments @offset INT, @count INT AS

SELECT COUNT(*) count FROM Enrollment

DECLARE @enrollments ENROLLMENT

INSERT INTO @enrollments SELECT enrollmentID, studentID, semester, date, batch academicYear FROM Enrollment
ORDER BY Enrollment.studentID OFFSET @offset ROWS FETCH NEXT @count ROWS ONLY

SELECT * FROM @enrollments

SELECT enrollmentID, moduleCode FROM EnrollmentModule WHERE enrollmentID IN (SELECT enrollmentID FROM @enrollments)
go

