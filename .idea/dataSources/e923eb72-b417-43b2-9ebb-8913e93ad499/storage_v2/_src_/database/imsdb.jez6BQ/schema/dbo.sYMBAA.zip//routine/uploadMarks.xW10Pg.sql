CREATE PROCEDURE uploadMarks @moduleCode CHAR(6), @date DATE, @academicYear INT, @marks MARK READONLY AS
    BEGIN TRANSACTION
    IF EXISTS(SELECT 1 FROM Exam WHERE moduleCode = @moduleCode AND academicYear = @academicYear)
        BEGIN
            SELECT 'Previously entered marks exist in the system' AS duplicateEntry
            GOTO errorhandler;
        END
    ELSE
        BEGIN
            INSERT INTO Exam(moduleCode, dateHeld, academicYear) VALUES (@moduleCode, @date, @academicYear);
            IF @@ROWCOUNT = 0 GOTO errorHandler;

            DECLARE cursor_marks CURSOR FOR SELECT * FROM @marks
            DECLARE @studentID CHAR(7), @mark INT, @grade VARCHAR(2), @enrollmentID INT

            OPEN cursor_marks
            FETCH NEXT FROM cursor_marks INTO @studentID, @mark
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    SELECT @enrollmentID = E.enrollmentID FROM Enrollment E, EnrollmentModule EM
                    WHERE E.studentID = @studentID
                      AND E.batch = @academicYear
                      AND E.enrollmentID = EM.enrollmentID
                      AND EM.moduleCode = @moduleCode
                    IF @enrollmentID IS NOT NULL
                        BEGIN
                            EXEC @grade = getGrade @mark
                            INSERT INTO Mark (examID, studentID, enrollmentID, mark, grade) VALUES (IDENT_CURRENT('Exam'), @studentID, @enrollmentID, @mark, @grade)
                            IF @@ROWCOUNT = 0 GOTO errorHandler
                            FETCH NEXT FROM cursor_marks INTO @studentID, @mark
                        END
                    ELSE
                        BEGIN
                            SELECT 'Found students who are not registered to the module' AS invalidStudentID
                            GOTO errorhandler
                        END
                END
        END

    COMMIT TRANSACTION
    RETURN 0;

    errorHandler:
    PRINT 'Error executing the query'
    ROLLBACK TRANSACTION
    RETURN -1
go

