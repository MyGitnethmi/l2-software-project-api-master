CREATE PROCEDURE updateRequestStatus @requestID INT,
                                     @submissionDate Date,
                                     @remarks VARCHAR(500),
                                     @finalDecision INT,
                                     @requests REQUEST_TYPE READONLY,
                                     @reasons REASONS READONLY,
                                     @progress PROGRESS READONLY AS

DELETE
FROM RequestProgress
WHERE requestID = @requestID
DELETE
FROM RequestReason
WHERE requestID = @requestID
DELETE
FROM RequestsMade
WHERE requestID = @requestID

UPDATE Request
SET date          = @submissionDate,
    remarks       = @remarks,
    finalDecision = @finalDecision
WHERE requestID = @requestID

DECLARE @requestTypeID INT
DECLARE
    cursor_requests CURSOR FOR SELECT *
                               FROM @requests
    OPEN cursor_requests
    FETCH NEXT FROM cursor_requests INTO @requestTypeID
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO RequestsMade(requestID, requestTypeID)
            VALUES (@requestID, @requestTypeID)
            FETCH NEXT FROM cursor_requests INTO @requestTypeID
        END

DECLARE @requestReason VARCHAR(150)
DECLARE
    cursor_reason CURSOR FOR SELECT *
                             FROM @reasons
    OPEN cursor_reason
    FETCH NEXT FROM cursor_reason INTO @requestReason
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO RequestReason(requestID, reason)
            VALUES (@requestID, @requestReason)
            FETCH NEXT FROM cursor_reason INTO @requestReason
        END

DECLARE @status INT, @reviewedBy INT, @reason VARCHAR(200)
DECLARE
    cursor_progress CURSOR FOR SELECT *
                               FROM @progress
    OPEN cursor_progress
    FETCH NEXT FROM cursor_progress INTO @status, @reviewedBy, @reason
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO RequestProgress (requestID, status, reviewedBy, reason)
            VALUES (@requestID, @status, @reviewedBy, @reason)
            FETCH NEXT FROM cursor_progress INTO @status, @reviewedBy, @reason
        END
go

