CREATE PROCEDURE checkIfResultsUploaded @moduleCode CHAR(6), @academicYear INT AS
    IF EXISTS(SELECT 1
              FROM Exam
              WHERE moduleCode = @moduleCode
                AND academicYear = @academicYear)
        RETURN -1;
    ELSE
        RETURN 1;
go

