CREATE PROCEDURE getDetailedAttendance @studentID CHAR(7), @moduleCode CHAR(6), @type CHAR(15), @batch INT AS

SELECT X.date, IIF(A.studentID IS NULL, CAST(1 AS BIT), CAST(0 AS BIT)) status
FROM (
         SELECT S.sessionID, S.date
         FROM LectureHour L,
              Session S
         WHERE L.moduleCode = @moduleCode
           AND L.type = @type
           AND S.lectureHourID = L.lectureHourID
           AND S.batch = @batch
     ) X
         LEFT JOIN Attendance A ON X.sessionID = A.sessionID AND A.studentID = @studentID
go

