create PROCEDURE [dbo].[registerStudent] @studentID CHAR(7),
                                         @password VARCHAR(300),
                                         @courseID VARCHAR(50),
                                         @academicYear INT,
                                         @fullName VARCHAR(100),
                                         @title VARCHAR(20),
                                         @nameWithInitials VARCHAR(50),
                                         @firstName VARCHAR(20),
                                         @lastName VARCHAR(20),
                                         @address VARCHAR(255),
                                         @district CHAR(5),
                                         @province CHAR(4),
                                         @dateOfBirth DATE,
                                         @race VARCHAR(15),
                                         @religion VARCHAR(15),
                                         @gender CHAR(1),
                                         @nic VARCHAR(12),
                                         @email VARCHAR(50),
                                         @mobile VARCHAR(12),
                                         @home VARCHAR(12),
                                         @designation VARCHAR(50),
                                         @employer VARCHAR(50),
                                         @company VARCHAR(50),
                                         @educationQualifications EDUCATION_QUALIFICATION READONLY
AS
    BEGIN TRANSACTION

INSERT INTO Users (username, password, email, firstName, lastName, role, recoveryEmail, verified, title, status)
VALUES (@studentID, @password, @email, @firstName, @lastName, 3, '', 0, @title, 1)
    IF @@ROWCOUNT = 0 GOTO errorHandler

INSERT INTO Student
VALUES (@studentID, @courseID, @fullName, @nameWithInitials, @address, @district, @province, @dateOfBirth, @race,
        @religion, @gender, @nic, @mobile, @home, @designation, @employer, @company, @academicyear)
    IF @@ROWCOUNT = 0 GOTO errorHandler

DECLARE
    cursor_educationQualifications CURSOR FOR SELECT *
                                              FROM @educationQualifications
DECLARE @degree VARCHAR(50), @institute VARCHAR(50), @dateCompleted DATE, @class VARCHAR(20)

    OPEN cursor_educationQualifications
    FETCH NEXT FROM cursor_educationQualifications INTO @degree, @institute, @dateCompleted, @class
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO EducationQualification (studentID, degree, institute, dateCompleted, class)
            VALUES (@studentID, @degree, @institute, @dateCompleted, @class)
            IF @@ROWCOUNT = 0 GOTO errorHandler
            FETCH NEXT FROM cursor_educationQualifications INTO @degree, @institute, @dateCompleted, @class
        END

    COMMIT TRANSACTION
    RETURN 0
    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction failed..!'
    RETURN -1
go

