CREATE PROCEDURE checkValidity @username CHAR(7), @token VARCHAR(300), @time BIGINT AS
    IF EXISTS(SELECT 1 FROM Users U WHERE U.username = @username)
        BEGIN

            DECLARE @lastActive BIGINT
            SELECT @lastActive = lastActive FROM ActiveSession WHERE userID = @username AND token = @token

            IF @lastActive IS NOT NULL
                BEGIN
                    IF (@time - @lastActive <= 7200000)
                        BEGIN
                            SELECT U.username, R.roleID, CONCAT(U.firstName, ' ', U.lastName) as name, U.verified, A.lastActive
                            FROM Users U, Role R, ActiveSession A
                            WHERE U.username = @username AND U.role = R.roleID
                            UPDATE ActiveSession SET lastActive = @time WHERE userID = @username
                            RETURN 1;
                        END
                    ELSE
                        BEGIN
                            RETURN 2;
                        END
                END
            ELSE
                BEGIN
                    RETURN 3;
                END
        END
    ELSE
        BEGIN
            RETURN 4;
        END
go

