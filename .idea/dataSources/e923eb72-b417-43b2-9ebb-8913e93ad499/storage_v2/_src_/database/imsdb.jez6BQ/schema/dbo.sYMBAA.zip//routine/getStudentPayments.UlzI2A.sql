CREATE PROCEDURE getStudentPayments @studentID CHAR(50) AS
SELECT P.amount,
       P.slipNo,
       P.paymentDate,
       P.confirmStatus,
       P.bank,
       S.studentID,
       U.title,
       S.fullName
FROM Payment P,
     Student S,
     Users U
WHERE P.studentID = @studentID
  AND P.confirmStatus = 2
  AND P.studentID = S.studentID
  AND S.StudentID = U.username
ORDER BY P.paymentDate ASC
go

