CREATE PROCEDURE getLectureHours @moduleCode CHAR(6) AS

SELECT moduleName
FROM Module
WHERE moduleCode = @moduleCode

SELECT lectureHourID, type
FROM LectureHour
WHERE moduleCode = @moduleCode
go

