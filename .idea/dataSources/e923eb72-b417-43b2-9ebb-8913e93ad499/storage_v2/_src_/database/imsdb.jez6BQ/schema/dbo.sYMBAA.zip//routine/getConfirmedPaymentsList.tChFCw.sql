create PROCEDURE getConfirmedPaymentsList @courseID INT, @academicYear INT AS
SELECT SUM(P.amount) AS totalPayment, S.studentID, U.title, S.fullName, C.courseName
FROM Payment P,
     Student S,
     Users U,
     Course C
WHERE P.confirmStatus = 2
  AND S.academicYear = @academicYear
  AND S.courseID = @courseID
  AND P.studentID = S.studentID
  AND S.StudentID = U.username
  AND S.courseId = C.courseID
GROUP BY S.studentID, U.title, S.fullName, C.courseName
go

