CREATE PROCEDURE modifyAttendance @sessionID INT, @attendance SESSION_ATTENDANCE READONLY
AS
    BEGIN TRANSACTION

DELETE FROM Attendance WHERE sessionID = @sessionID

DECLARE @studentID CHAR(7), @status BIT

DECLARE cursor_attendance CURSOR FOR SELECT * FROM @attendance
    OPEN cursor_attendance
    FETCH NEXT FROM cursor_attendance INTO @studentID, @status

    WHILE @@FETCH_STATUS = 0
        BEGIN
            IF EXISTS(
                    SELECT 1 FROM LectureHour L, Session S, Enrollment E, EnrollmentModule EM
                    WHERE S.sessionID = @sessionID AND S.lectureHourID = L.lectureHourID AND L.moduleCode = EM.moduleCode AND EM.enrollmentID = E.enrollmentID AND E.batch = S.batch AND E.studentID = @studentID
                )
                BEGIN
                    IF (@status = 0)
                        BEGIN
                            INSERT INTO Attendance VALUES (@sessionID, @studentID)
                            IF @@ROWCOUNT = 0 GOTO errorHandler
                        END
                    FETCH NEXT FROM cursor_attendance INTO @studentID, @status
                END
            ELSE
                BEGIN
                    GOTO errorHandler
                END
        END

    COMMIT TRANSACTION
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction failed!'
    RETURN -1;
go

