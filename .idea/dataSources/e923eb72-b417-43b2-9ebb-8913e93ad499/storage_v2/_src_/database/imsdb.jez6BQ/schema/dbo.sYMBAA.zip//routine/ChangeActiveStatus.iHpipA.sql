CREATE PROCEDURE ChangeActiveStatus @username CHAR(7), @token VARCHAR(300), @lastActive BIGINT AS
    IF EXISTS(SELECT 1
              FROM ActiveSession
              WHERE userID = @username)
        BEGIN
            UPDATE ActiveSession SET token = @token, lastActive = @lastActive WHERE userID = @username
        END
    ELSE
        BEGIN
            INSERT INTO ActiveSession (userID, token, lastActive) VALUES (@username, @token, @lastActive)
        END
    RETURN 0;
go

