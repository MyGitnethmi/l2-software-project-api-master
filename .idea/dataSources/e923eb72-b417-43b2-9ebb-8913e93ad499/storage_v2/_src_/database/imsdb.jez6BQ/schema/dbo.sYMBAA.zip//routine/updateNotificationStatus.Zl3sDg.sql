CREATE PROCEDURE updateNotificationStatus @receiverID CHAR(7), @notifications NOTIFICATIONS READONLY AS
    BEGIN TRANSACTION
UPDATE Received
SET received = 1
WHERE recipientID = @receiverID
  AND notificationID IN (SELECT notificationID FROM @notifications);
    COMMIT TRANSACTION
go

