CREATE PROCEDURE enrollStudent @studentID CHAR(7), @semester INT, @academicYear INT,
                               @modules REGISTRATION_MODULE READONLY AS
    BEGIN TRANSACTION
INSERT INTO Enrollment (studentID, semester, date, batch)
VALUES (@studentID, @semester, GETDATE(), @academicYear)

DECLARE @moduleCode CHAR(6)
DECLARE
    cursor_modules CURSOR FOR SELECT *
                              FROM @modules;
    OPEN cursor_modules;
    FETCH NEXT FROM cursor_modules INTO @moduleCode;

    WHILE @@fetch_status = 0
        BEGIN
            INSERT INTO EnrollmentModule
            VALUES (IDENT_CURRENT('Enrollment'), @moduleCode);
            FETCH NEXT FROM cursor_modules INTO @moduleCode
        END
    COMMIT TRANSACTION
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION;
    PRINT 'Transaction failed';
    RETURN -1;
go

