CREATE PROCEDURE getRequestsBrief @studentID CHAR(7) AS
SELECT requestID, date
FROM Request
WHERE submittedBy = @studentID
SELECT R.requestID, RM.requestTypeID, RT.request
FROM RequestsMade RM,
     RequestType RT,
     Request R
WHERE R.submittedBY = @studentID
  AND R.requestID = RM.requestID
  AND RM.requestTypeID = RT.requestTypeID
go

