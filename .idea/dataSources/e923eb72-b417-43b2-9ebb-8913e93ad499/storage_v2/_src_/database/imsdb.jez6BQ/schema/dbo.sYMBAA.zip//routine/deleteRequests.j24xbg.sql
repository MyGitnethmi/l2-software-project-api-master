CREATE PROCEDURE deleteRequests @username CHAR(7), @role INT, @requestIDs REQUEST_ID READONLY AS
    BEGIN TRANSACTION

DECLARE @requestID INT
DECLARE
    cursor_lectureHour CURSOR FOR SELECT *
                                  FROM @requestIDs
    OPEN cursor_lectureHour
    FETCH NEXT FROM cursor_lectureHour INTO @requestID
    IF @role = 3
        BEGIN
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    DELETE FROM RequestProgress WHERE requestID = @requestID
                    DELETE FROM RequestReason WHERE requestID = @requestID
                    DELETE FROM RequestsMade WHERE requestID = @requestID
                    DELETE FROM Request WHERE submittedBY = @username AND requestID = @requestID
                    IF @@ROWCOUNT = 0 GOTO errorHandler
                    FETCH NEXT FROM cursor_lectureHour INTO @requestID
                END
        END
    ELSE
        IF @role = 1
            BEGIN
                WHILE @@FETCH_STATUS = 0
                    BEGIN
                        DELETE FROM RequestProgress WHERE requestID = @requestID
                        DELETE FROM RequestReason WHERE requestID = @requestID
                        DELETE FROM RequestsMade WHERE requestID = @requestID
                        DELETE FROM Request WHERE requestID = @requestID
                        IF @@ROWCOUNT = 0 GOTO errorHandler
                        FETCH NEXT FROM cursor_lectureHour INTO @requestID
                    END
            END

    COMMIT TRANSACTION
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction Failed..!'
    RETURN -1
go

