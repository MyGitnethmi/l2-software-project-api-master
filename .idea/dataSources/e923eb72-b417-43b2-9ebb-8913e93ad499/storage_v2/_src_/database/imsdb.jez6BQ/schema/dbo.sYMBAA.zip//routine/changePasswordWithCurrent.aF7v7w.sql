CREATE PROCEDURE changePasswordWithCurrent @username CHAR(7), @newPassword VARCHAR(50), @currentPassword VARCHAR(50) AS
    IF EXISTS(SELECT 1
              FROM Users
              WHERE username = @username)
        BEGIN
            IF @currentPassword = (SELECT password FROM Users WHERE username = @username)
                BEGIN
                    UPDATE Users SET password = @newPassword WHERE username = @username
                    RETURN 0;
                END
            ELSE
                RETURN -1;
        END
    ELSE
        BEGIN
            RETURN -1;
        END
go

