CREATE PROCEDURE checkUserCredentials @username CHAR(7) AS
    IF EXISTS(SELECT 1
              FROM Users
              WHERE username = @username)
        BEGIN
            SELECT U.username, U.password, U.firstName, U.lastName, U.email, R.roleName as role, U.verified
            FROM Users U,
                 Role R
            WHERE U.username = @username
              AND U.role = R.roleID
            RETURN 0;
        END
    ELSE
        BEGIN
            RETURN -1;
        END
go

