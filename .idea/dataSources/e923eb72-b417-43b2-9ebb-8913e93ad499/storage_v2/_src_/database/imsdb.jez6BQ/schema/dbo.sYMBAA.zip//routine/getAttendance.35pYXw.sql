CREATE PROC getAttendance @studentID CHAR(7) AS
SELECT D.moduleCode, D.moduleName, D.type, D.batch, COUNT(a.sessionID) AS count, D.total
FROM (
         SELECT M.moduleName, L.moduleCode, L.type, S.batch, S.sessionID, SC.count total
         FROM Module M,
              LectureHour L,
              Session S,
              Enrollment E,
              EnrollmentModule EM,
              SessionCount SC
         WHERE E.studentID = @studentID
           AND E.enrollmentID = EM.enrollmentID
           AND EM.moduleCode = L.moduleCode
           AND E.batch = S.batch
           AND L.lectureHourID = S.lectureHourID
           AND SC.moduleCode = L.moduleCode
           AND SC.type = L.type
           AND SC.batch = S.batch
           AND M.moduleCode = L.moduleCode
     ) D
         LEFT JOIN Attendance A ON D.sessionID = A.sessionID AND A.studentID = @studentID
GROUP BY D.moduleCode, D.moduleName, D.type, D.batch, D.total
go

