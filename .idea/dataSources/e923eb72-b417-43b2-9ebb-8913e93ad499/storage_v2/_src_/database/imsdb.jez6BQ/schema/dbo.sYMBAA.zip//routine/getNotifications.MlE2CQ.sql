CREATE PROCEDURE getNotifications @username CHAR(7) AS

SELECT N.sentBy, N.notificationID, N.subject, N.message, U.firstName + ' ' + U.lastName sender, N.timeSent, R.received
FROM Notification N,
     Received R,
     Users U
WHERE R.recipientID = @username
  AND R.notificationID = N.notificationID
  AND U.username = N.sentBy
  AND N.timeSent >= DATEADD(MONTH, -2, GETDATE())

SELECT R.notificationID, R.recipientID FROM Received R, Notification N WHERE N.sentBy = @username AND N.notificationID = R.notificationID
go

