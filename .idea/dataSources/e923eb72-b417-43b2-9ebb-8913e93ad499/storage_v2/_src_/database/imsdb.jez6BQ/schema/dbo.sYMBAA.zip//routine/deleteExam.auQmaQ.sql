CREATE PROCEDURE deleteExam @moduleCode CHAR(6), @academicYear INT AS
    BEGIN TRANSACTION

DECLARE @examID INT
SELECT @examID = examID FROM Exam WHERE moduleCode = @moduleCode AND academicYear = @academicyear
    IF @@ROWCOUNT = 0 GOTO errorHandler

DELETE FROM Mark WHERE examID = @examID
    IF @@ROWCOUNT = 0 GOTO errorHandler

DELETE FROM Exam WHERE moduleCode = @moduleCode AND academicYear = @academicyear
    IF @@ROWCOUNT = 0 GOTO errorHandler

    COMMIT TRANSACTION
    RETURN 0;

    errorHandler:
    PRINT 'Transaction failed'
    ROLLBACK TRANSACTION
    RETURN -1;
go

