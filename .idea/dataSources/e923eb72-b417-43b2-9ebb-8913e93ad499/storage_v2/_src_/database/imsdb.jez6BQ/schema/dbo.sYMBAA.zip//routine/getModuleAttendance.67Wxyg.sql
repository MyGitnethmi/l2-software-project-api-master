CREATE PROCEDURE getModuleAttendance @moduleCode CHAR(6) AS

SELECT Y.moduleCode,
       Y.moduleName,
       Y.type,
       Y.date,
       Y.sessionID,
       Y.batch,
       Y.count,
       EC.count as total
FROM (
         SELECT moduleName, moduleCode, type, date, X.sessionID, batch, COUNT(studentID) count
         FROM (
                  SELECT M.moduleName, L.moduleCode, L.type, S.date, S.sessionID, S.batch
                  FROM LectureHour L,
                       Session S,
                       Module M
                  WHERE L.moduleCode = @moduleCode
                    AND L.moduleCode = M.moduleCode
                    AND L.lectureHourID = S.lectureHourID
              ) X
                  LEFT JOIN Attendance A ON X.sessionID = A.sessionID
         GROUP BY moduleCode, moduleName, type, date, batch, X.sessionID) Y,
     EnrollmentCount EC
WHERE EC.moduleCode = @moduleCode
  AND EC.batch = Y.batch
go

