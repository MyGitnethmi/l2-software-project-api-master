CREATE VIEW SessionCount AS
SELECT L.moduleCode, M.moduleName, L.type, S.batch, COUNT(*) count
FROM LectureHour L,
     Session S,
     Module M
WHERE L.lectureHourID = S.lectureHourID
  AND L.moduleCode = M.moduleCode
GROUP BY L.moduleCode, M.moduleName, L.type, S.batch
go

