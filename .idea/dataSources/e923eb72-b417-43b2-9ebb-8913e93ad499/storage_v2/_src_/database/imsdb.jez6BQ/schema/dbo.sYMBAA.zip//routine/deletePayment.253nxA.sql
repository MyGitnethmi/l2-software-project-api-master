create PROCEDURE deletePayment @slipNo INT AS
    BEGIN TRANSACTION
    IF EXISTS(SELECT *
              FROM Payment
              WHERE slipNo = @slipNo)
        BEGIN

            UPDATE Payment
            SET confirmStatus= 0
            WHERE slipNo = @slipNo
            IF @@ROWCOUNT = 0 GOTO errorHandler
        END
    COMMIT TRANSACTION
    RETURN 0
    errorHandler:
    PRINT 'Transaction failed'
    ROLLBACK TRANSACTION
    RETURN -1
go

