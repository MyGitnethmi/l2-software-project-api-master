CREATE PROCEDURE checkModule @moduleCode CHAR(6) AS
    IF EXISTS(SELECT 1 FROM Module
              WHERE moduleCode = @moduleCode)
        BEGIN
            SELECT moduleName FROM Module WHERE moduleCode = @moduleCode
            RETURN 0
        END
    ELSE
        BEGIN
            RETURN 1
        END
go

