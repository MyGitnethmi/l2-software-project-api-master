create PROCEDURE editPayment @slipNo INT, @amount INT, @paymentDate Date, @bank Char(20)AS
    BEGIN TRANSACTION
    IF EXISTS(SELECT *
              FROM Payment
              WHERE slipNo = @slipNo)
        BEGIN

            UPDATE Payment
            SET amount= @amount,
                paymentDate= @paymentDate,
                bank= @bank,
                confirmStatus = 2
            WHERE slipNo = @slipNo
            IF @@ROWCOUNT = 0 GOTO errorHandler
        END
    COMMIT TRANSACTION
    RETURN 0
    errorHandler:
    PRINT 'Transaction failed'
    ROLLBACK TRANSACTION
    RETURN -1
go

