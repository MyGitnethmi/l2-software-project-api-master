CREATE PROCEDURE tot @studentID CHAR(50) AS
SELECT  S.studentID, SUM(P.amount) AS TOTAL,(450000 - SUM(P.amount)) AS REMAIN
FROM Payment P,
     Student S
WHERE P.studentID = @studentID
  AND P.confirmStatus = 1
  AND P.studentID = S.studentID
GROUP BY  S.studentID
go

