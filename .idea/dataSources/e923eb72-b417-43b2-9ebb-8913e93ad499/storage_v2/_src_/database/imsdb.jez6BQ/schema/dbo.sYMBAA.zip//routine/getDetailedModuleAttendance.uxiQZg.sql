CREATE PROCEDURE getDetailedModuleAttendance @moduleCode CHAR(6), @batch INT, @sessionID INT AS

SELECT X.studentID, IIF(A.studentID IS NULL, CAST(1 AS BIT), CAST(0 AS BIT)) status
FROM (
         SELECT E.studentID
         FROM Enrollment E,
              EnrollmentModule EM
         WHERE EM.moduleCode = @moduleCode
           AND EM.enrollmentID = E.enrollmentID
           AND E.batch = @batch
     ) X
         LEFT JOIN
     (
         SELECT A.studentID
         FROM LectureHour L,
              Session S,
              Attendance A
         WHERE L.moduleCode = @moduleCode
           AND S.lectureHourID = L.lectureHourID
           AND S.sessionID = @sessionID
           AND S.sessionID = A.sessionID
     ) A ON A.studentID = X.studentID
go

