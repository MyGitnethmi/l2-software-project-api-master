CREATE PROCEDURE getRequests @studentID CHAR(7) AS

SELECT requestID, date, remarks, finalDecision
FROM Request
WHERE submittedBY = @studentID

SELECT R.requestID, RT.request
FROM RequestsMade RM,
     RequestType RT,
     Request R
WHERE R.submittedBY = @studentID
  AND R.requestID = RM.requestID
  AND RM.requestTypeID = RT.requestTypeID

SELECT R.requestID, RR.reason
FROM RequestReason RR,
     Request R
WHERE R.submittedBY = @studentID
  AND R.requestID = RR.requestID

SELECT R.requestID, RP.status, RP.reason, RR.reviewer
FROM RequestProgress RP,
     RequestReviewer RR,
     Request R
WHERE R.submittedBY = @studentID
  AND R.requestID = RP.requestID
  AND RP.reviewedBy = RR.reviewerID
go

