CREATE PROCEDURE getAllRequests AS
SELECT *
FROM Request
SELECT RM.requestID, RT.request
FROM RequestsMade RM,
     RequestType RT
WHERE RM.requestTypeID = RT.requestTypeID
SELECT requestID
FROM Request R
WHERE EXISTS(SELECT 1 FROM RequestProgress RP WHERE R.requestID = RP.requestID)
go

