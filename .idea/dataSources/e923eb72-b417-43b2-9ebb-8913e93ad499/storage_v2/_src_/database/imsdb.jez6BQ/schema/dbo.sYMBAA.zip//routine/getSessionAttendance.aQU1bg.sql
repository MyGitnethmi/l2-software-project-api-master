CREATE PROCEDURE getSessionAttendance @sessionID INT AS
DECLARE @moduleCode CHAR(6), @batch INT
SELECT @moduleCode = L.moduleCode, @batch = S.batch
FROM LectureHour L,
     Session S
WHERE S.sessionID = @sessionID
  AND L.lectureHourID = S.lectureHourID
    PRINT @moduleCode
    PRINT @batch
SELECT D.studentID AS StudentID, IIF(A.studentID IS NULL, 'Present', 'Absent') AS status
FROM (SELECT E.studentID
      FROM Enrollment E,
           EnrollmentModule EM
      WHERE EM.moduleCode = @moduleCode
        AND EM.enrollmentID = E.enrollmentID
        AND E.batch = @batch) D
         LEFT JOIN Attendance A ON A.sessionID = @sessionID AND D.studentID = A.studentID
go

