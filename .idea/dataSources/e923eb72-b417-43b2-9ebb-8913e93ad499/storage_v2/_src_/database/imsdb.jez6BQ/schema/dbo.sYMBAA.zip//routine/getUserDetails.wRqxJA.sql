CREATE PROCEDURE getUserDetails @username VARCHAR(7), @roleID INT AS
    IF NOT EXISTS(SELECT 1
                  FROM Users
                  WHERE username = @username)
        RETURN -1;

    IF @roleID = 1
        BEGIN
            SELECT U.username,
                   U.firstName,
                   U.lastName,
                   A.fullName,
                   A.mobile,
                   A.designation,
                   U.email,
                   U.recoveryEmail,
                   R.roleName
            FROM Users U,
                 Admin A,
                 Role R
            WHERE username = @username
              AND U.role = R.roleID
        END
    ELSE
        IF @roleID = 2
            BEGIN
                SELECT U.username,
                       U.firstName,
                       U.lastName,
                       T.fullName,
                       T.mobile,
                       T.designation,
                       R.roleName,
                       U.email,
                       U.recoveryEmail
                FROM Users U,
                     Teacher T,
                     Role R
                WHERE username = @username
                  AND U.role = R.roleID
            END
        ELSE
            BEGIN
                SELECT U.username,
                       R.roleName,
                       U.firstName,
                       U.lastName,
                       U.email,
                       U.recoveryEmail,
                       S.fullName,
                       C.courseName,
                       S.address,
                       S.dateOfBirth,
                       S.nic,
                       S.mobile,
                       S.home,
                       S.designation,
                       S.company,
                       S.academicYear
                FROM Student S,
                     Users U,
                     Course C,
                     Role R
                WHERE U.username = @username
                  AND U.username = S.studentID
                  AND S.courseID = C.courseID
                  AND U.role = R.roleID;
            END

SELECT degree, institute, dateCompleted, class
FROM EducationQualification
WHERE studentID = @username
    RETURN 0;
go

