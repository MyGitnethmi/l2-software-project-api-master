CREATE PROCEDURE checkStudentID @studentID CHAR(7) AS
    IF EXISTS(SELECT 1
              FROM Student S,
                   Course C
              WHERE studentID = @studentID
                AND C.courseID = S.courseID)
        BEGIN
            SELECT S.fullName name, C.courseName course, S.academicYear academicYear
            FROM Student S,
                 Course C
            WHERE studentID = @studentID
              AND C.courseID = S.courseID;
            RETURN 0;
        END
    ELSE
        RETURN -1;
go

