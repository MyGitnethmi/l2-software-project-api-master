CREATE PROCEDURE addVerificationRequest @username CHAR(7), @email VARCHAR(50), @token VARCHAR(300) AS
    IF EXISTS(SELECT 1
              FROM VerificationRequests
              WHERE username = @username)
        BEGIN
            UPDATE VerificationRequests SET email = @email, token = @token WHERE username = @username
        END
    ELSE
        BEGIN
            INSERT INTO VerificationRequests (username, email, token)
            VALUES (@username, @email, @token)
        END
go

