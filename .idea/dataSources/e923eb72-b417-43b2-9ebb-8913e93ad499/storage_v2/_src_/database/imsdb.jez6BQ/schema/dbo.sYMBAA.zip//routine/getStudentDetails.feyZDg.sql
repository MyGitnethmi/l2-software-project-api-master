CREATE PROCEDURE getStudentDetails @StudentID CHAR(7) AS
    IF EXISTS(SELECT 1
              FROM Student
              WHERE studentID = @StudentID)
        BEGIN
            SELECT U.username,
                   R.roleName,
                   U.firstName,
                   U.lastName,
                   U.email,
                   U.recoveryEmail,
                   S.fullName,
                   C.courseName,
                   S.address,
                   S.dateOfBirth,
                   S.nic,
                   S.mobile,
                   S.home,
                   S.designation,
                   S.company,
                   S.academicYear
            FROM Student S,
                 Users U,
                 Course C,
                 Role R
            WHERE U.username = @StudentID
              AND U.username = S.studentID
              AND S.courseID = C.courseID
              AND U.role = R.roleID;
            SELECT degree, institute, dateCompleted, class FROM EducationQualification WHERE studentID = @StudentID
            RETURN 0;
        END
    ELSE
        RETURN -1;
go

