CREATE PROCEDURE deleteNotification @notificationID INT, @username CHAR(7) AS
BEGIN
    IF @username = (SELECT sentBy FROM Notification WHERE notificationID = @notificationID)
        BEGIN
            DELETE FROM Received WHERE notificationID = @notificationID
            DELETE FROM Notification WHERE notificationID = @notificationID
            RETURN 0;
        END
    ELSE
        RETURN -1;
END
go

