CREATE PROCEDURE getRegisteredUsersList @courseID INT, @academicyear INT AS
SELECT U.title, S.fullName, S.nic, U.email, S.mobile, S.studentID
FROM Student S,
     Users U
WHERE S.academicYear = @academicyear
  AND S.courseID = @courseID
  AND S.studentID = U.username
  AND U.role = 3
  AND U.status = 1
GROUP BY U.title, S.fullName, S.nic, U.email, S.mobile, S.studentID
go

