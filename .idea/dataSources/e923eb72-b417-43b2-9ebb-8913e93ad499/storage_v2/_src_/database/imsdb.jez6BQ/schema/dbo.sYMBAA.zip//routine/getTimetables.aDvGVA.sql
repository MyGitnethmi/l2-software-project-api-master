CREATE PROCEDURE getTimetables @username CHAR(7), @role INT AS
    IF @role = 1 OR @role = 2
        BEGIN
            SELECT L.moduleCode,
                   M.moduleName,
                   L.lectureHourID,
                   L.type,
                   L.startingTime,
                   L.endingTime,
                   L.day,
                   L.lectureHall
            FROM LectureHour L,
                 Module M
            WHERE L.moduleCode = M.moduleCode
        END
    ELSE
        BEGIN
            SELECT MAX(E.date) date,
                   L.moduleCode,
                   M.moduleName,
                   L.lectureHourID,
                   L.type,
                   L.startingTime,
                   L.endingTime,
                   L.day,
                   L.LectureHall
            FROM LectureHour L,
                 Module M,
                 Enrollment E,
                 EnrollmentModule EM
            WHERE E.studentID = @username
              AND EM.enrollmentID = E.enrollmentID
              AND EM.moduleCode = M.moduleCode
              AND M.moduleCode = L.moduleCode
            GROUP BY L.moduleCode, M.moduleName, L.lectureHourID, L.type, L.startingTime, L.endingTime, L.day,
                     L.LectureHall
        END
go

