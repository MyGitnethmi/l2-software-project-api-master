CREATE PROCEDURE deleteEnrollments @enrollmentIDs ENROLLMENT_ID READONLY AS
    BEGIN TRANSACTION

DECLARE @enrollmentID INT, @studentID CHAR(7)
DECLARE cursor_enrollments CURSOR FOR SELECT * FROM @enrollmentIDs
    OPEN cursor_enrollments
    FETCH NEXT FROM cursor_enrollments INTO @enrollmentID

    WHILE @@FETCH_STATUS = 0
        BEGIN

            SELECT @studentID = studentID FROM Enrollment WHERE enrollmentID = @enrollmentID

            DELETE FROM Attendance WHERE studentID = @studentID and sessionID IN (
                SELECT S.sessionID as sessionID
                FROM Session S, Attendance A, Enrollment E, EnrollmentModule EM, LectureHour L
                WHERE E.enrollmentID = @enrollmentID AND
                        E.enrollmentID = EM.enrollmentID AND
                        EM.moduleCode = L.moduleCode AND
                        L.lectureHourID = S.lectureHourID AND
                        E.batch = S.batch AND
                        S.sessionID = A.sessionID AND
                        A.studentID = @studentID
            )

            DELETE FROM Mark WHERE studentID = @studentID AND enrollmentID = @enrollmentID

            DELETE FROM EnrollmentModule WHERE enrollmentID = @enrollmentID

            DELETE FROM Enrollment WHERE  enrollmentID = @enrollmentID
            IF @@ROWCOUNT = 0 GOTO errorHandler

            FETCH NEXT FROM cursor_enrollments INTO @enrollmentID

        END

    COMMIT TRANSACTION
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    PRINT 'Transaction failed'
    RETURN -1;
go

