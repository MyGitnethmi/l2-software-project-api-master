CREATE PROCEDURE checkVerificationRequest @username CHAR(7), @email VARCHAR(50), @token VARCHAR(300) AS
    IF EXISTS(SELECT 1
              FROM VerificationRequests
              WHERE username = @username
                AND email = @email
                AND token = @token)
        BEGIN
            DELETE FROM VerificationRequests WHERE username = @username
            RETURN 0;
        END
    ELSE
        RETURN -1;
go

