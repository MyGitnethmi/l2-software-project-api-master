create procedure getPaymentDetails @username char(7), @role int, @paymentID int as

    if (@role = 3)
        begin
            if exists(select 1 from payment where id = @paymentID and studentID = @username)
                begin
                    select * from payment where id = @paymentID and studentID = @username
                end
            else
                begin
                    return -1
                end
        end
    else
        begin
            select * from Payment where id = @paymentID
        end
    return 0
go

