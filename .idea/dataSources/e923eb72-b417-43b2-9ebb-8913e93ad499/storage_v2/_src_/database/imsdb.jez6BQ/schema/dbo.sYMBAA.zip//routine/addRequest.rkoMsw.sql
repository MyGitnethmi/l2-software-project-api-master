CREATE PROCEDURE addRequest @new BIT, @requestID INT, @role INT, @StudentID CHAR(7), @date DATE, @remarks VARCHAR(500),
                            @requests REQUEST_TYPE READONLY, @reasons REASON READONLY AS

DECLARE @requestIDs REQUEST_ID
DECLARE @returnValue INT
INSERT INTO @requestIDs
VALUES (@requestID)
    IF @new = 0
        BEGIN
            EXEC @returnValue = deleteRequests @StudentID, @role, @requestIDs
            IF @returnValue <> 0 RETURN -1
        END

INSERT INTO Request (submittedBY, date, remarks)
VALUES (@StudentID, @date, @remarks)

DECLARE @request INT, @reason VARCHAR(150)

DECLARE
    cursor_requestTypes CURSOR FOR SELECT *
                                   FROM @requests
    OPEN cursor_requestTypes
    FETCH NEXT FROM cursor_requestTypes INTO @request
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO RequestsMade (requestID, requestTypeID)
            VALUES (ident_current('Request'), @request)
            FETCH NEXT FROM cursor_requestTypes INTO @request
        END

DECLARE
    cursor_reasons CURSOR FOR SELECT *
                              FROM @reasons
    OPEN cursor_reasons
    FETCH NEXT FROM cursor_reasons INTO @reason
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO RequestReason (requestID, reason)
            VALUES (IDENT_CURRENT('Request'), @reason)
            FETCH NEXT FROM cursor_reasons INTO @reason
        END

    RETURN IDENT_CURRENT('Request');
go

